//
//  ViewController.swift
//  Calculator
//
//  Created by Batuhan Baştürk on 26.11.2019.
//  Copyright © 2019 Batuhan Basturk. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var secondNumber: UITextField!
    @IBOutlet weak var firstNumber: UITextField!
    
    var result=0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func sumClick(_ sender: Any) {
        if let fNum=Int(firstNumber.text!){
            if let sNum=Int(secondNumber.text!){
                        result=fNum+sNum
                      resultLabel.text = String(result)
            }else{ resultLabel.text="Wrong number second"}
        }else{ resultLabel.text="Wrong number first"}
    }
    @IBAction func minusClick(_ sender: Any) {
        if let fNum=Int(firstNumber.text!){
                 if let sNum=Int(secondNumber.text!){
                             result=fNum-sNum
                           resultLabel.text = String(result)
                 }else{ resultLabel.text="Wrong number second"}
             }else{ resultLabel.text="Wrong number first"}
    }
    
    @IBAction func multiplyClick(_ sender: Any) {
        if let fNum=Int(firstNumber.text!){
                 if let sNum=Int(secondNumber.text!){
                             result=fNum*sNum
                           resultLabel.text = String(result)
                 }else{ resultLabel.text="Wrong number second"}
             }else{ resultLabel.text="Wrong number first"}
    }
    
    
    @IBAction func divedClick(_ sender: Any) {
        if let fNum=Int(firstNumber.text!){
                 if let sNum=Int(secondNumber.text!){
                             result=fNum/sNum
                           resultLabel.text = String(result)
                 }else{ resultLabel.text="Wrong number second"}
             }else{ resultLabel.text="Wrong number first"}
    }
    
    @IBAction func modClick(_ sender: Any) {
        if let fNum=Int(firstNumber.text!){
                 if let sNum=Int(secondNumber.text!){
                             result=fNum%sNum
                           resultLabel.text = String(result)
                 }else{ resultLabel.text="Wrong number second"}
             }else{ resultLabel.text="Wrong number first"}
    }
    
    
}

